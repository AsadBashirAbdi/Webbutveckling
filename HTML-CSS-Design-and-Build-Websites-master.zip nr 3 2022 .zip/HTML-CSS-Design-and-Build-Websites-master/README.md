# HTML-CSS-Design-and-Build-Websites-by-Jon-Duckett
This repo consists of example snippets from HTML &amp; CSS Design and Build Websites Book by Jon Duckett

If you open the index.html file in your web browser you will be able to try all of the code examples from this one page.

You should be able to double click on this file to open it in your browser. If this does not work, open your web browser, go to the File menu, select open and browse to find the file on your computer.

You can also try these examples online at http://www.htmlandcssbook.com/code-samples/